
class Porco extends classeBase{
    constructor(x,y){
        super(x,y,50,50);
        this.imagem = loadImage("porco.png");
    }
    show(){
        super.show()
    }

}