class Caixa extends classeBase {
    constructor(x, y) {
        super(x,y,70,70)
        this.imagem = loadImage('madeira.png')
    }
    show(){
        super.show();
    }

}